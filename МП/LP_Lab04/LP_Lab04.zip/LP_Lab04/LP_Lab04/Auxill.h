#pragma once
#include <cstdlib>
namespace Auxil
{
	void start();
	double dget(double rmin, double rmax);
	int iget(int rmin, int rmax);
}
